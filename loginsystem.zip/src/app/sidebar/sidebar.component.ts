import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent {
  @Input() sidenavStatus : boolean = false;
  sidebarContent = [
    {
      number : '1',
      name : 'home',
      icon : 'fa-solid fa-house'
    },
    {
      number : '2',
      name : 'Analytics',
      icon : 'fa-solid fa-chart-line'
    },
    {
      number : '3',
      name : 'products',
      icon : 'fa-solid fa-box'
    },
    {
      number : '4',
      name : 'order',
      icon : 'fa-solid fa-cart-shopping'
    },
    {
      number : '5',
      name : 'setting',
      icon : 'fa-solid fa-gear'
    },
    {
      number : '6',
      name : 'about',
      icon : 'fa-solid fa-circle-info'
    },
    {
      number : '7',
      name : 'contact',
      icon : 'fa-solid fa-phone'
    }  
  ]

}
